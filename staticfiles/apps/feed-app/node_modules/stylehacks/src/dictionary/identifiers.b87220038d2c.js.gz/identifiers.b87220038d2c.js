'use strict';
const MEDIA_QUERY = 'media query';
const PROPERTY = 'property';
const SELECTOR = 'selector';
const VALUE = 'value';

module.exports = { MEDIA_QUERY, PROPERTY, SELECTOR, VALUE };
