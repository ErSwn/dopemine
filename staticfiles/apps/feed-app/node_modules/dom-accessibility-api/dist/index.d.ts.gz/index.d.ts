export { computeAccessibleDescription } from "./accessible-description";
export { computeAccessibleName } from "./accessible-name";
export { default as getRole } from "./getRole";
export * from "./is-inaccessible";
//# sourceMappingURL=index.d.ts.map