/**
 * Safe Element.localName for all supported environments
 * @param element
 */
export declare function getLocalName(element: Element): string;
export default function getRole(element: Element): string | null;
//# sourceMappingURL=getRole.d.ts.map