/**
 * Creates an array from an iterable object.
 * @param iterable An iterable object to convert to an array.
 */
export default function arrayFrom<T>(iterable: Iterable<T> | ArrayLike<T>): T[];
//# sourceMappingURL=array.from.d.ts.map