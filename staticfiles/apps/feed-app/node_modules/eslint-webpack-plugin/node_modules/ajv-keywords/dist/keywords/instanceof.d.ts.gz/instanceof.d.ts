import type { Plugin } from "ajv";
declare const instanceofPlugin: Plugin<undefined>;
export default instanceofPlugin;
