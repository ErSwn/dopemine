import type { SchemaCxt } from "..";
import { Name } from "../codegen";
export declare function topBoolOrEmptySchema(it: SchemaCxt): void;
export declare function boolOrEmptySchema(it: SchemaCxt, valid: Name): void;
