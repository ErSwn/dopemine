'use strict';
module.exports = new Map([
  [['repeat', 'no-repeat'].toString(), 'repeat-x'],
  [['no-repeat', 'repeat'].toString(), 'repeat-y'],
  [['repeat', 'repeat'].toString(), 'repeat'],
  [['space', 'space'].toString(), 'space'],
  [['round', 'round'].toString(), 'round'],
  [['no-repeat', 'no-repeat'].toString(), 'no-repeat'],
]);
