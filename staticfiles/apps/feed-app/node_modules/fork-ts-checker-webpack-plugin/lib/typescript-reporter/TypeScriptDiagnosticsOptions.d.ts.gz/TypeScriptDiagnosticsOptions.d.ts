interface TypeScriptDiagnosticsOptions {
    syntactic: boolean;
    semantic: boolean;
    declaration: boolean;
    global: boolean;
}
export { TypeScriptDiagnosticsOptions };
