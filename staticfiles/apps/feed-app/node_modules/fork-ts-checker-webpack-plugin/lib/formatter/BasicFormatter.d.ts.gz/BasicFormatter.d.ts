import { Formatter } from './Formatter';
declare function createBasicFormatter(): Formatter;
export { createBasicFormatter };
