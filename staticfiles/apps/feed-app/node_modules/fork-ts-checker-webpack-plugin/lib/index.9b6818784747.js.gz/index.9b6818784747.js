"use strict";
const ForkTsCheckerWebpackPlugin_1 = require("./ForkTsCheckerWebpackPlugin");
module.exports = ForkTsCheckerWebpackPlugin_1.ForkTsCheckerWebpackPlugin;
