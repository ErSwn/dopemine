"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function unique(array) {
    return Array.from(new Set(array));
}
exports.default = unique;
