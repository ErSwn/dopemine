# Installation
> `npm install --save @types/estree`

# Summary
This package contains type definitions for ESTree AST specification (https://github.com/estree/estree).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree

Additional Details
 * Last updated: Tue, 17 Apr 2018 20:22:09 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by RReverser <https://github.com/RReverser>.
