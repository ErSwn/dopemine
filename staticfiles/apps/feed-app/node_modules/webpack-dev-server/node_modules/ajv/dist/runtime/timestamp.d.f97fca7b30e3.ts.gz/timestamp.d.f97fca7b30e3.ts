declare function validTimestamp(str: string, allowDate: boolean): boolean;
declare namespace validTimestamp {
    var code: string;
}
export default validTimestamp;
