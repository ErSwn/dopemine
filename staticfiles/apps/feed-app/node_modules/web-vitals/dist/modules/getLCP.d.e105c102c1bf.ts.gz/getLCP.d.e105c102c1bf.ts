import { ReportHandler } from './types.js';
export declare const getLCP: (onReport: ReportHandler, reportAllChanges?: boolean | undefined) => void;
