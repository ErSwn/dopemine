import { ReportHandler } from './types.js';
export declare const getFCP: (onReport: ReportHandler, reportAllChanges?: boolean | undefined) => void;
