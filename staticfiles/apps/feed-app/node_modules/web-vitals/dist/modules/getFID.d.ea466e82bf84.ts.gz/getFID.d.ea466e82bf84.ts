import { ReportHandler } from './types.js';
export declare const getFID: (onReport: ReportHandler, reportAllChanges?: boolean | undefined) => void;
