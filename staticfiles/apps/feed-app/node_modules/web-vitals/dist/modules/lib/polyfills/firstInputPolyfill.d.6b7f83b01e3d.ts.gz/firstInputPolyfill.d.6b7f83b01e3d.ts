import { FirstInputPolyfillCallback } from '../../types.js';
/**
 * Accepts a callback to be invoked once the first input delay and event
 * are known.
 */
export declare const firstInputPolyfill: (onFirstInput: FirstInputPolyfillCallback) => void;
export declare const resetFirstInputPolyfill: () => void;
