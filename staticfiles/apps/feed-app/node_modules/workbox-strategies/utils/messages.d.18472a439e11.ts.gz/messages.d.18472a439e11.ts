import '../_version.js';
export declare const messages: {
    strategyStart: (strategyName: string, request: Request) => string;
    printFinalResponse: (response?: Response | undefined) => void;
};
