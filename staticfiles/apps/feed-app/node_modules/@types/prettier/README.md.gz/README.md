# Installation
> `npm install --save @types/prettier`

# Summary
This package contains type definitions for prettier (https://prettier.io).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/prettier.

### Additional Details
 * Last updated: Tue, 20 Dec 2022 12:32:40 GMT
 * Dependencies: none
 * Global values: `prettier`

# Credits
These definitions were written by [Ika](https://github.com/ikatyang), [Ifiok Jr.](https://github.com/ifiokjr), [Florian Imdahl](https://github.com/ffflorian), [Sosuke Suzuki](https://github.com/sosukesuzuki), [Christopher Quadflieg](https://github.com/Shinigami92), [Georgii Dolzhykov](https://github.com/thorn0), [JounQin](https://github.com/JounQin), and [Chuah Chee Shian](https://github.com/shian15810).
