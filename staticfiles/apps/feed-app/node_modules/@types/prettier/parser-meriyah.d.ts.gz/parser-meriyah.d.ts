import { Parser } from '.';

declare const parser: {
    parsers: {
        meriyah: Parser;
    };
};
export = parser;
