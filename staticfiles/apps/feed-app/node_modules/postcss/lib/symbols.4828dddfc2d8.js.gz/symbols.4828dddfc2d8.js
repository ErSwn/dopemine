'use strict'

module.exports.isClean = Symbol('isClean')

module.exports.my = Symbol('my')
