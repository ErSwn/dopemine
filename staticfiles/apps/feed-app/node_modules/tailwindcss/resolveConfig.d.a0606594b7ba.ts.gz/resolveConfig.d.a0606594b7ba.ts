import type { Config } from './types/config'
declare function resolveConfig(config: Config): Config
export = resolveConfig
