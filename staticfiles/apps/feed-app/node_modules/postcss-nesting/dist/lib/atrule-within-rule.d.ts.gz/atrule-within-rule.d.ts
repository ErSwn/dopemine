import { options } from './options.js';
import { walkFunc } from './walk-func.js';
import type { AtRule, Rule } from 'postcss';
export default function atruleWithinRule(node: AtRule, parent: Rule, walk: walkFunc, opts: options): void;
export declare function isAtruleWithinRule(node: AtRule): boolean;
