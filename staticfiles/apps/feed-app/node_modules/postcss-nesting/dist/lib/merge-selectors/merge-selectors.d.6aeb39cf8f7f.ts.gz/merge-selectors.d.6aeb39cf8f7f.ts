import { options } from '../options';
export default function mergeSelectors(fromSelectors: Array<string>, toSelectors: Array<string>, opts: options): any[];
