import React from 'react';
export default class App extends React.Component {
    state: {
        items: unknown[];
    };
    fetchMoreData: () => void;
    render(): JSX.Element;
}
