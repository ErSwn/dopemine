import type { Plugin } from "ajv";
export { AjvKeywordsError } from "./definitions";
declare const ajvKeywords: Plugin<string | string[]>;
export default ajvKeywords;
