"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const _range_1 = __importDefault(require("./_range"));
const getDef = (0, _range_1.default)("exclusiveRange");
exports.default = getDef;
module.exports = getDef;
//# sourceMappingURL=exclusiveRange.js.map