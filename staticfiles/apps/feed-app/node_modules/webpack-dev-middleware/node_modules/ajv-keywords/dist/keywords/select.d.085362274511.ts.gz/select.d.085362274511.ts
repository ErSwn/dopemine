import type { Plugin } from "ajv";
import type { DefinitionOptions } from "../definitions/_types";
declare const select: Plugin<DefinitionOptions>;
export default select;
