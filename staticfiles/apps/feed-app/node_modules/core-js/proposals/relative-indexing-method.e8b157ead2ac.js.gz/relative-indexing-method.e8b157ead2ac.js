// https://github.com/tc39/proposal-relative-indexing-method
require('../modules/es.string.at-alternative');
require('../modules/esnext.array.at');
require('../modules/esnext.typed-array.at');
