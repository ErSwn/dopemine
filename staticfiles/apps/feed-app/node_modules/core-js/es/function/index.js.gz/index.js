require('../../modules/es.function.bind');
require('../../modules/es.function.name');
require('../../modules/es.function.has-instance');
var path = require('../../internals/path');

module.exports = path.Function;
