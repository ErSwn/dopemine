require('../../modules/es.reflect.get-prototype-of');
var path = require('../../internals/path');

module.exports = path.Reflect.getPrototypeOf;
