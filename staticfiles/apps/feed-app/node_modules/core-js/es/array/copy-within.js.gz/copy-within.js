require('../../modules/es.array.copy-within');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'copyWithin');
