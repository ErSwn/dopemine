require('../../../modules/es.array.fill');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').fill;
