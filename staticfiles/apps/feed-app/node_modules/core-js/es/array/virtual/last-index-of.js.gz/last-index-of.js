require('../../../modules/es.array.last-index-of');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').lastIndexOf;
