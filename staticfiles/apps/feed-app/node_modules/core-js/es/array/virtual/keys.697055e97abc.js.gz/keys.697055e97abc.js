require('../../../modules/es.array.iterator');
require('../../../modules/es.object.to-string');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').keys;
