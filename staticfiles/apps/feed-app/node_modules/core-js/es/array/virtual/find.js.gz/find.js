require('../../../modules/es.array.find');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').find;
