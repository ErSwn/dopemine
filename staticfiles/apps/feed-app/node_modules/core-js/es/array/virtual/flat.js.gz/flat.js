require('../../../modules/es.array.flat');
require('../../../modules/es.array.unscopables.flat');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').flat;
