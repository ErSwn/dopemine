require('../../modules/es.date.to-primitive');
require('../../modules/es.symbol.to-primitive');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('toPrimitive');
