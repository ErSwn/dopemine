require('../../modules/es.regexp.exec');
require('../../modules/es.regexp.test');
var uncurryThis = require('../../internals/function-uncurry-this');

module.exports = uncurryThis(/./.test);
