require('../../modules/es.regexp.constructor');
require('../../modules/es.regexp.dot-all');
require('../../modules/es.regexp.exec');
require('../../modules/es.regexp.sticky');

module.exports = RegExp;
