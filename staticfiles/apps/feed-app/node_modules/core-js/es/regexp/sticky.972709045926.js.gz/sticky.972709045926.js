require('../../modules/es.regexp.constructor');
require('../../modules/es.regexp.exec');
require('../../modules/es.regexp.sticky');

module.exports = function (it) {
  return it.sticky;
};
