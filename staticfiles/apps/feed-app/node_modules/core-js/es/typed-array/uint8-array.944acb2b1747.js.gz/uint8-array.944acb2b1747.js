require('../../modules/es.array-buffer.constructor');
require('../../modules/es.array-buffer.slice');
require('../../modules/es.typed-array.uint8-array');
require('./methods');
var global = require('../../internals/global');

module.exports = global.Uint8Array;
