require('../../modules/es.string.raw');
var path = require('../../internals/path');

module.exports = path.String.raw;
