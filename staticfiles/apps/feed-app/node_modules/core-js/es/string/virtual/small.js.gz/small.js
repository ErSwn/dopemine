require('../../../modules/es.string.small');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').small;
