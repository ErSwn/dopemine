require('../../../modules/es.string.pad-start');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').padStart;
