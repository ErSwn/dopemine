require('../../../modules/es.string.trim-end');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').trimRight;
