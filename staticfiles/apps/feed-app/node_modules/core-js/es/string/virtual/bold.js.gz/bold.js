require('../../../modules/es.string.bold');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').bold;
