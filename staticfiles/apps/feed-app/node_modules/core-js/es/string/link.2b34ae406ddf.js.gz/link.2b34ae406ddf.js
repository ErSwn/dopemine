require('../../modules/es.string.link');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'link');
