require('../../modules/es.string.fixed');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'fixed');
