require('../../modules/es.string.sup');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'sup');
