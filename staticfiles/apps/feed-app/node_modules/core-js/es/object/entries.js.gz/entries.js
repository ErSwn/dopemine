require('../../modules/es.object.entries');
var path = require('../../internals/path');

module.exports = path.Object.entries;
