require('../../modules/es.object.is-extensible');
var path = require('../../internals/path');

module.exports = path.Object.isExtensible;
