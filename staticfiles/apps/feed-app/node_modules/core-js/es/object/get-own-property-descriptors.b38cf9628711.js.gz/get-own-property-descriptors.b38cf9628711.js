require('../../modules/es.object.get-own-property-descriptors');
var path = require('../../internals/path');

module.exports = path.Object.getOwnPropertyDescriptors;
