require('../../modules/es.object.prevent-extensions');
var path = require('../../internals/path');

module.exports = path.Object.preventExtensions;
