var parent = require('../../stable/typed-array/int16-array');
require('../../actual/typed-array/methods');

module.exports = parent;
