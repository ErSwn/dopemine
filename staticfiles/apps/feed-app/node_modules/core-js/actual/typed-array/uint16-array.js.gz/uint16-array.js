var parent = require('../../stable/typed-array/uint16-array');
require('../../actual/typed-array/methods');

module.exports = parent;
