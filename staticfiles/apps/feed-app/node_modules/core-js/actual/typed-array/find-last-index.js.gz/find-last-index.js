require('../../modules/esnext.typed-array.find-last-index');
var parent = require('../../stable/typed-array/find-last-index');

module.exports = parent;
