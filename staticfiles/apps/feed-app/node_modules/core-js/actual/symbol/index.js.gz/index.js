var parent = require('../../stable/symbol');

require('../../modules/esnext.symbol.dispose');

module.exports = parent;
