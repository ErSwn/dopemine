var parent = require('../../actual/iterator');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.iterator.as-indexed-pairs');
require('../../modules/esnext.iterator.indexed');

module.exports = parent;
