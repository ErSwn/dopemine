// TODO: remove from `core-js@4`
require('../../modules/esnext.string.replace-all');

var parent = require('../../actual/string/replace-all');

module.exports = parent;
