require('../../actual/string/at');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.string.at');

module.exports = require('../../internals/entry-unbind')('String', 'at');
