var parent = require('../../actual/function');
require('../../modules/esnext.function.is-callable');
require('../../modules/esnext.function.is-constructor');
require('../../modules/esnext.function.un-this');

module.exports = parent;
