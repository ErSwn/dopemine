var parent = require('../es/get-iterator-method');
require('../modules/web.dom-collections.iterator');

module.exports = parent;
