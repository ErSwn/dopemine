var parent = require('../../es/typed-array/int16-array');
require('../../stable/typed-array/methods');

module.exports = parent;
