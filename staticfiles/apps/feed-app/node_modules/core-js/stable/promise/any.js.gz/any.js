var parent = require('../../es/promise/any');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
