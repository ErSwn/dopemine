var parent = require('../../es/weak-set');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
