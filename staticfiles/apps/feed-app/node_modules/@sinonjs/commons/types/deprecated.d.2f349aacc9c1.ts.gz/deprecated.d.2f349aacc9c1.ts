export function wrap(func: Function, msg: string): Function;
export function defaultMsg(packageName: string, funcName: string): string;
export function printWarning(msg: string): undefined;
