"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jtdForms = void 0;
exports.jtdForms = [
    "elements",
    "values",
    "discriminator",
    "properties",
    "optionalProperties",
    "enum",
    "type",
    "ref",
];
//# sourceMappingURL=types.js.map