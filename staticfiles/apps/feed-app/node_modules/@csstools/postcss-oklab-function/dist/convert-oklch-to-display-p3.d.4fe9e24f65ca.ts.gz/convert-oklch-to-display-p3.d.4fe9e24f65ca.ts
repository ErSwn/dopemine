declare type color = [number, number, number];
export declare function oklchToDisplayP3(oklchRaw: color): [color, boolean];
export {};
