declare type color = [number, number, number];
export declare function oklabToSRgb(oklabRaw: color): color;
export {};
