import type { Declaration, Result } from 'postcss';
import { pluginOptions } from './index';
declare const remFunctionCheck = "rem(";
declare function transformRemFunction(decl: Declaration, result: Result, options: pluginOptions): string | undefined;
export { remFunctionCheck, transformRemFunction };
