import type { PluginCreator } from 'postcss';
declare const creator: PluginCreator<{
    preserve: boolean;
}>;
export default creator;
