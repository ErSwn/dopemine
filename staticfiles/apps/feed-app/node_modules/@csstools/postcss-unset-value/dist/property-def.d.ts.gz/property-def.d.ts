export declare const inherited: Set<string>;
export declare const nonInherited: Set<string>;
