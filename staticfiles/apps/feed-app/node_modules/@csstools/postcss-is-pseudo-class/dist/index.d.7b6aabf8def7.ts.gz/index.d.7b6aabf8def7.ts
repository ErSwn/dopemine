import type { PluginCreator } from 'postcss';
declare type pluginOptions = {
    preserve?: boolean;
    onComplexSelector?: 'warning';
    onPseudoElement?: 'warning';
    specificityMatchingName?: string;
};
declare const creator: PluginCreator<pluginOptions>;
export default creator;
