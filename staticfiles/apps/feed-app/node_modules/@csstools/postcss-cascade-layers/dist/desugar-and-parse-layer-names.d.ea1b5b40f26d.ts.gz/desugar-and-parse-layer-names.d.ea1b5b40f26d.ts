import type { Container } from 'postcss';
import type { Model } from './model';
export declare function desugarAndParseLayerNames(root: Container, model: Model): void;
