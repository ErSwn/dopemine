import type { PluginCreator } from 'postcss';
/** Transform hwb() functions in CSS. */
declare const postcssPlugin: PluginCreator<{
    preserve: boolean;
}>;
export default postcssPlugin;
