declare type color = [number, number, number];
export declare function prophotoRgbToSRgb(prophoto: color): color;
export {};
