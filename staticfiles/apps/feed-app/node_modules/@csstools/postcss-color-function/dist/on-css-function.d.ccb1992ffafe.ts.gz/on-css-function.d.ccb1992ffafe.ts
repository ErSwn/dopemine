import type { Declaration, Result } from 'postcss';
import type { FunctionNode } from 'postcss-value-parser';
export declare function onCSSFunctionSRgb(node: FunctionNode, decl: Declaration, result: Result, preserve: boolean): void;
