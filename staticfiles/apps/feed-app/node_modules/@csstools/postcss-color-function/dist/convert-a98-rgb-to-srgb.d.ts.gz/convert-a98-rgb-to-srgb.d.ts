declare type color = [number, number, number];
export declare function a98RgbToSRgb(a98: color): color;
export {};
