declare type color = [number, number, number];
export declare function displayP3ToSRgb(displayP3: color): color;
export {};
