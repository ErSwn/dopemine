declare type color = [number, number, number];
export declare function rec2020ToSRgb(rec: color): color;
export {};
