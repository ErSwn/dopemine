import * as equal from "fast-deep-equal";
type Equal = typeof equal & {
    code: string;
};
declare const _default: Equal;
export default _default;
