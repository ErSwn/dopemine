import { ManifestTransform } from '../types';
export declare function maximumSizeTransform(maximumFileSizeToCacheInBytes: number): ManifestTransform;
