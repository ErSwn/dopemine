import { BuildType } from '../types';
export declare function getModuleURL(moduleName: string, buildType: BuildType): string;
