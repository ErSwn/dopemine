export declare function rebasePath({ baseDirectory, file, }: {
    baseDirectory: string;
    file: string;
}): string;
