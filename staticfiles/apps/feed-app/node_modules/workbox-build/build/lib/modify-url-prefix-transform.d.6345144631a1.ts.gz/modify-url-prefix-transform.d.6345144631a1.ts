import { ManifestTransform } from '../types';
export declare function modifyURLPrefixTransform(modifyURLPrefix: {
    [key: string]: string;
}): ManifestTransform;
