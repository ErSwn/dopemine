declare function commonPathPrefix(paths: string[], sep?: string): string;

export = commonPathPrefix;
