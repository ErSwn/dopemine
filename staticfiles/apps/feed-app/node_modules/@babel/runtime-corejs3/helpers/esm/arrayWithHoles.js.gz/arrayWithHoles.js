import _Array$isArray from "@babel/runtime-corejs3/core-js/array/is-array";
export default function _arrayWithHoles(arr) {
  if (_Array$isArray(arr)) return arr;
}