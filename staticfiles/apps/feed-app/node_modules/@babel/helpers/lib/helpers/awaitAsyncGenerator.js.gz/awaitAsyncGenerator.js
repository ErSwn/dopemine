"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _awaitAsyncGenerator;
var _OverloadYield = require("OverloadYield");

function _awaitAsyncGenerator(value) {
  return new _OverloadYield(value, 0);
}

//# sourceMappingURL=awaitAsyncGenerator.js.map
