"use strict";

exports.__esModule = true;
exports.defineProvider = defineProvider;

function defineProvider(factory) {
  // This will allow us to do some things
  return factory;
}