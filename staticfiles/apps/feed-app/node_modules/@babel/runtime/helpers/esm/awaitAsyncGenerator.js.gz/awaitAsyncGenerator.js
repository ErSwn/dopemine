import OverloadYield from "./OverloadYield.js";
export default function _awaitAsyncGenerator(value) {
  return new OverloadYield(value, 0);
}