"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _development.default;
  }
});

var _development = require("@babel/plugin-transform-react-jsx/lib/development");