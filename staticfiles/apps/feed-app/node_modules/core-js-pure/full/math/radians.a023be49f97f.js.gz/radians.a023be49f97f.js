require('../../modules/esnext.math.radians');
var path = require('../../internals/path');

module.exports = path.Math.radians;
