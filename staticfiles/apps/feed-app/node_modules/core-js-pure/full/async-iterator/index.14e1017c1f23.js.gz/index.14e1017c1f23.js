var parent = require('../../actual/async-iterator');
require('../../modules/esnext.async-iterator.async-dispose');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.async-iterator.as-indexed-pairs');
require('../../modules/esnext.async-iterator.indexed');

module.exports = parent;
