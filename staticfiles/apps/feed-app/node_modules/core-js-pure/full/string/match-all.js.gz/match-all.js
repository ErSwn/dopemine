// TODO: remove from `core-js@4`
require('../../modules/esnext.string.match-all');

var parent = require('../../actual/string/match-all');

module.exports = parent;
