require('../../../modules/esnext.function.un-this');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Function').unThis;
