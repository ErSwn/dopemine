var parent = require('../../../actual/function/virtual');
require('../../../modules/esnext.function.un-this');

module.exports = parent;
