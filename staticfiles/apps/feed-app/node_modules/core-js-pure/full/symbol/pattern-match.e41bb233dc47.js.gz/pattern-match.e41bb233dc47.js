// TODO: Remove from `core-js@4`
require('../../modules/esnext.symbol.pattern-match');
var WrappedWellKnownSymbolModule = require('../../internals/well-known-symbol-wrapped');

module.exports = WrappedWellKnownSymbolModule.f('patternMatch');
