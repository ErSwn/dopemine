var parent = require('../../actual/symbol');
require('../../modules/esnext.symbol.async-dispose');
require('../../modules/esnext.symbol.matcher');
require('../../modules/esnext.symbol.metadata-key');
require('../../modules/esnext.symbol.observable');
// TODO: Remove from `core-js@4`
require('../../modules/esnext.symbol.metadata');
require('../../modules/esnext.symbol.pattern-match');
require('../../modules/esnext.symbol.replace-all');

module.exports = parent;
