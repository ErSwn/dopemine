require('../../modules/es.regexp.exec');
require('../../modules/es.string.search');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'search');
