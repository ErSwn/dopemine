require('../../../modules/es.string.blink');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').blink;
