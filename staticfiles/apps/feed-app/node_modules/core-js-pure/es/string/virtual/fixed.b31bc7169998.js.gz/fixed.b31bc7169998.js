require('../../../modules/es.string.fixed');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('String').fixed;
