require('../../modules/es.regexp.exec');
require('../../modules/es.string.split');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('String', 'split');
