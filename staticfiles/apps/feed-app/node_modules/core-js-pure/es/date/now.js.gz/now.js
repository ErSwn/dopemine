require('../../modules/es.date.now');
var path = require('../../internals/path');

module.exports = path.Date.now;
