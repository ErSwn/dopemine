require('../../modules/es.number.parse-int');
var path = require('../../internals/path');

module.exports = path.Number.parseInt;
