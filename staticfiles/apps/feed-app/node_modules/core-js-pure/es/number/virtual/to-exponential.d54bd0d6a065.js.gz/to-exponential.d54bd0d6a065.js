require('../../../modules/es.number.to-exponential');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Number').toExponential;
