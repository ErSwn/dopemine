require('../../../modules/es.array.some');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').some;
