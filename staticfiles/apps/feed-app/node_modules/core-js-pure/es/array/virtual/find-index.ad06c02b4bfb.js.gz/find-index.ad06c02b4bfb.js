require('../../../modules/es.array.find-index');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').findIndex;
