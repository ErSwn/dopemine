require('../../../modules/es.array.push');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').push;
