require('../../modules/es.array.for-each');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'forEach');
