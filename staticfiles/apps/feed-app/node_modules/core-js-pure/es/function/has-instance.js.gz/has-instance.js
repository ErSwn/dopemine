require('../../modules/es.function.has-instance');
var wellKnownSymbol = require('../../internals/well-known-symbol');

module.exports = Function[wellKnownSymbol('hasInstance')];
