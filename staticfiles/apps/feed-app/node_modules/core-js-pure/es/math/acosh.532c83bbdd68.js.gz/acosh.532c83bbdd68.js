require('../../modules/es.math.acosh');
var path = require('../../internals/path');

module.exports = path.Math.acosh;
