require('../../modules/es.math.cbrt');
var path = require('../../internals/path');

module.exports = path.Math.cbrt;
