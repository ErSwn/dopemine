require('../../modules/es.object.freeze');
var path = require('../../internals/path');

module.exports = path.Object.freeze;
