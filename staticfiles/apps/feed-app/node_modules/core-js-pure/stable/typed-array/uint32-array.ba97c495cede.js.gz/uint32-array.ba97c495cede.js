var parent = require('../../es/typed-array/uint32-array');
require('../../stable/typed-array/methods');

module.exports = parent;
