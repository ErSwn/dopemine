require('../modules/es.error.to-string');
require('../modules/es.object.to-string');
require('../modules/web.btoa');
require('../modules/web.dom-exception.constructor');
require('../modules/web.dom-exception.stack');
require('../modules/web.dom-exception.to-string-tag');
var path = require('../internals/path');

module.exports = path.btoa;
