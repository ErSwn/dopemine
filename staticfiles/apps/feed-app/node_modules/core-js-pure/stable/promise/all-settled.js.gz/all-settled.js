var parent = require('../../es/promise/all-settled');
require('../../modules/web.dom-collections.iterator');

module.exports = parent;
