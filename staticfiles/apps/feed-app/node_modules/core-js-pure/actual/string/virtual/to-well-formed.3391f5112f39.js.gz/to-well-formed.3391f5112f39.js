require('../../../modules/esnext.string.to-well-formed');

module.exports = require('../../../internals/entry-virtual')('String').toWellFormed;
