var parent = require('../../stable/string');

require('../../modules/esnext.string.is-well-formed');
require('../../modules/esnext.string.to-well-formed');

module.exports = parent;
