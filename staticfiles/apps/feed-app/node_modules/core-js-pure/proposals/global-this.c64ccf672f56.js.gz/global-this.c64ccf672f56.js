// https://github.com/tc39/proposal-global
require('../modules/esnext.global-this');
var global = require('../internals/global');

module.exports = global;
