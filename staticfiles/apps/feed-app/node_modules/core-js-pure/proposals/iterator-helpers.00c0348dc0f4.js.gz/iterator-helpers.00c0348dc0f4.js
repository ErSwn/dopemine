// TODO: remove from `core-js@4`
// https://github.com/tc39/proposal-iterator-helpers
require('./iterator-helpers-stage-3');
require('../modules/esnext.async-iterator.as-indexed-pairs');
require('../modules/esnext.async-iterator.indexed');
require('../modules/esnext.iterator.as-indexed-pairs');
require('../modules/esnext.iterator.indexed');
