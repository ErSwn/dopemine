// TODO: Renamed, remove from `core-js@4`
// https://github.com/tc39/proposal-explicit-resource-management
require('../modules/esnext.symbol.async-dispose');
require('../modules/esnext.symbol.dispose');
