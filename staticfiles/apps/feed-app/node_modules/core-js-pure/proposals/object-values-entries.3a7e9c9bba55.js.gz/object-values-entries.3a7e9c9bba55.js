// https://github.com/tc39/proposal-object-values-entries
require('../modules/es.object.entries');
require('../modules/es.object.values');
