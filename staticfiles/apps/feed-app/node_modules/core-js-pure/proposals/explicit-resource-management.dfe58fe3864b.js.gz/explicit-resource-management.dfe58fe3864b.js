// https://github.com/tc39/proposal-explicit-resource-management
require('../modules/esnext.suppressed-error.constructor');
require('../modules/esnext.disposable-stack.constructor');
require('../modules/esnext.iterator.dispose');
require('../modules/esnext.symbol.dispose');
