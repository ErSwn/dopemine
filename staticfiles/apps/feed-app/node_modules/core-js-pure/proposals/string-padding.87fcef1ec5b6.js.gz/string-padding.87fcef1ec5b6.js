// https://github.com/tc39/proposal-string-pad-start-end
require('../modules/es.string.pad-end');
require('../modules/es.string.pad-start');
