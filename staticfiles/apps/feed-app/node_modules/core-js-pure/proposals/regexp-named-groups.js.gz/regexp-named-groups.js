// https://github.com/tc39/proposal-regexp-named-groups
require('../modules/es.regexp.constructor');
require('../modules/es.regexp.exec');
require('../modules/es.string.replace');
