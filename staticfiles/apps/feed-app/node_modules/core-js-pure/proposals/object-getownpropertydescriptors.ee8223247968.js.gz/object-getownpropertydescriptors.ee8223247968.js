// https://github.com/tc39/proposal-object-getownpropertydescriptors
require('../modules/es.object.get-own-property-descriptors');
