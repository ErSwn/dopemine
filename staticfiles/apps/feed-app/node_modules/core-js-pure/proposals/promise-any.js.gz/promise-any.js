// https://github.com/tc39/proposal-promise-any
require('../modules/esnext.aggregate-error');
require('../modules/esnext.promise.any');
