This folder contains implementations of polyfills. It's not recommended to include in your projects directly if you don't completely understand what are you doing.
