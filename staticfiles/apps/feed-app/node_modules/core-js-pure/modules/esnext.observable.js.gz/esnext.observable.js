// TODO: Remove this module from `core-js@4` since it's split to modules listed below
require('../modules/esnext.observable.constructor');
require('../modules/esnext.observable.from');
require('../modules/esnext.observable.of');
