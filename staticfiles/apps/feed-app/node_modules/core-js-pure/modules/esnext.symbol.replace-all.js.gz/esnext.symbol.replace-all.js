// TODO: remove from `core-js@4`
var defineWellKnownSymbol = require('../internals/well-known-symbol-define');

defineWellKnownSymbol('replaceAll');
