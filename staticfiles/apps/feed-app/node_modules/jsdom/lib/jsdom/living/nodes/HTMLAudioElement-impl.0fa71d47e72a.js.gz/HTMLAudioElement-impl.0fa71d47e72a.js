"use strict";

const HTMLMediaElementImpl = require("./HTMLMediaElement-impl").implementation;

class HTMLAudioElementImpl extends HTMLMediaElementImpl { }

module.exports = {
  implementation: HTMLAudioElementImpl
};
