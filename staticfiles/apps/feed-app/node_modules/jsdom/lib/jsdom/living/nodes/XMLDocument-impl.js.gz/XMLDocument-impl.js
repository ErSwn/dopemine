"use strict";
const DocumentImpl = require("./Document-impl").implementation;

exports.implementation = class XMLDocumentImpl extends DocumentImpl {};
