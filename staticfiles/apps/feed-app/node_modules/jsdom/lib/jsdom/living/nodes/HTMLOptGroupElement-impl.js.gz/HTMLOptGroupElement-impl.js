"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLOptGroupElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLOptGroupElementImpl
};
