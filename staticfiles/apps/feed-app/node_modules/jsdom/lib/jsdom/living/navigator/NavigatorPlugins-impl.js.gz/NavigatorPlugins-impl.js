"use strict";

exports.implementation = class NavigatorPluginsImpl {
  // plugins and mimeTypes are implemented in Navigator-impl.js
  javaEnabled() {
    return false;
  }
};
