"use strict";

// https://dom.spec.whatwg.org/#interface-nonelementparentnode
// getElementById is implemented separately inside Document and DocumentFragment.
class NonElementParentNodeImpl {

}

module.exports = {
  implementation: NonElementParentNodeImpl
};
