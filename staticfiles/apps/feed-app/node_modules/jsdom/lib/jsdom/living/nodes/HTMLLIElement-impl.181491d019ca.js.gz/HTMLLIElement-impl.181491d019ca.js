"use strict";

const HTMLElementImpl = require("./HTMLElement-impl").implementation;

class HTMLLIElementImpl extends HTMLElementImpl { }

module.exports = {
  implementation: HTMLLIElementImpl
};
