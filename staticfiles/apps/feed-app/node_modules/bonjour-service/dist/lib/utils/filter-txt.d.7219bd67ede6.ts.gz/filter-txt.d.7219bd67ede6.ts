import KeyValue from '../KeyValue';
declare const _default: (data: KeyValue) => {};
export default _default;
