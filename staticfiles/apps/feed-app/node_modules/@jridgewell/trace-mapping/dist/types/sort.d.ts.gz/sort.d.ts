import type { SourceMapSegment } from './sourcemap-segment';
export default function maybeSort(mappings: SourceMapSegment[][], owned: boolean): SourceMapSegment[][];
