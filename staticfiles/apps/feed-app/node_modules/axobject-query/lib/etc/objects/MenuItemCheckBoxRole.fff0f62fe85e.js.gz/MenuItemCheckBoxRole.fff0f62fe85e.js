"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var MenuItemCheckBoxRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'menuitemcheckbox'
    }
  }],
  type: 'widget'
};
var _default = MenuItemCheckBoxRole;
exports["default"] = _default;