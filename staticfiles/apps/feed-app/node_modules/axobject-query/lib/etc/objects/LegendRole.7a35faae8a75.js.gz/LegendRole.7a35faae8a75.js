"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var LegendRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'legend'
    }
  }],
  type: 'structure'
};
var _default = LegendRole;
exports["default"] = _default;