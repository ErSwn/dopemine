"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var DivRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'div'
    }
  }],
  type: 'generic'
};
var _default = DivRole;
exports["default"] = _default;