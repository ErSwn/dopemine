"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var ComplementaryRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'complementary'
    }
  }],
  type: 'structure'
};
var _default = ComplementaryRole;
exports["default"] = _default;