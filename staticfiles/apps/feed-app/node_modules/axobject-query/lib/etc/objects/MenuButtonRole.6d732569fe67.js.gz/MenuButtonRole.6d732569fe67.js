"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var MenuButtonRole = {
  relatedConcepts: [],
  type: 'widget'
};
var _default = MenuButtonRole;
exports["default"] = _default;