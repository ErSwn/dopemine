"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var MarkRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'mark'
    }
  }],
  type: 'structure'
};
var _default = MarkRole;
exports["default"] = _default;