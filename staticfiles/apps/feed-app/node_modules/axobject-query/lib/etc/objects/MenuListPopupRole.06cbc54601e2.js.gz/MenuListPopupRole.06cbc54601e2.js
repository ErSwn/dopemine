"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var MenuListPopupRole = {
  relatedConcepts: [],
  type: 'widget'
};
var _default = MenuListPopupRole;
exports["default"] = _default;