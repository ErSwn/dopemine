"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var DescriptionListRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'dl'
    }
  }],
  type: 'structure'
};
var _default = DescriptionListRole;
exports["default"] = _default;