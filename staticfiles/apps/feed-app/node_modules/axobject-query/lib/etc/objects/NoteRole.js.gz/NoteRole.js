"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var NoteRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'note'
    }
  }],
  type: 'structure'
};
var _default = NoteRole;
exports["default"] = _default;