"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var PreRole = {
  relatedConcepts: [{
    module: 'HTML',
    concept: {
      name: 'pre'
    }
  }],
  type: 'structure'
};
var _default = PreRole;
exports["default"] = _default;