"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var OutlineRole = {
  relatedConcepts: [],
  type: 'structure'
};
var _default = OutlineRole;
exports["default"] = _default;