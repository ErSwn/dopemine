"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var PopUpButtonRole = {
  relatedConcepts: [],
  type: 'widget'
};
var _default = PopUpButtonRole;
exports["default"] = _default;