import type * as ts from 'typescript';
export declare function getTypeArguments(type: ts.TypeReference, checker: ts.TypeChecker): readonly ts.Type[];
//# sourceMappingURL=getTypeArguments.d.ts.map