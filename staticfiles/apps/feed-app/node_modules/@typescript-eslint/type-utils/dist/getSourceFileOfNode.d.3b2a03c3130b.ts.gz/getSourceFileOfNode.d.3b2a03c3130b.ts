import * as ts from 'typescript';
/**
 * Gets the source file for a given node
 */
export declare function getSourceFileOfNode(node: ts.Node): ts.SourceFile;
//# sourceMappingURL=getSourceFileOfNode.d.ts.map