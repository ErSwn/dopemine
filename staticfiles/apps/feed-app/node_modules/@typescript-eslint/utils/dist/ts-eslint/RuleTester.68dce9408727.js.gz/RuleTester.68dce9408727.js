"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuleTester = void 0;
const eslint_1 = require("eslint");
class RuleTester extends eslint_1.RuleTester {
}
exports.RuleTester = RuleTester;
//# sourceMappingURL=RuleTester.js.map