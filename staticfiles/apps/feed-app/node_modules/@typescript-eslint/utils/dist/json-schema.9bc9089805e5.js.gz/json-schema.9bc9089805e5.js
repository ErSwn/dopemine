"use strict";
// Note - @types/json-schema@7.0.4 added some function declarations to the type package
// If we do export *, then it will also export these function declarations.
// This will cause typescript to not scrub the require from the build, breaking anyone who doesn't have it as a dependency
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=json-schema.js.map