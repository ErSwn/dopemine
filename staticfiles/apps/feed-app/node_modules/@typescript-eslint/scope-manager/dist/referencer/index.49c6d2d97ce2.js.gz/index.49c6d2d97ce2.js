"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Referencer = void 0;
var Referencer_1 = require("./Referencer");
Object.defineProperty(exports, "Referencer", { enumerable: true, get: function () { return Referencer_1.Referencer; } });
//# sourceMappingURL=index.js.map