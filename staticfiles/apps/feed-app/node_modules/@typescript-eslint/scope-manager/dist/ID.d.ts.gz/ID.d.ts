declare function createIdGenerator(): () => number;
declare function resetIds(): void;
export { createIdGenerator, resetIds };
//# sourceMappingURL=ID.d.ts.map