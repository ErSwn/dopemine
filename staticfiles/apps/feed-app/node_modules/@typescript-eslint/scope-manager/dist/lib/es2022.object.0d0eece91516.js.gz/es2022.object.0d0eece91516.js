"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2022_object = void 0;
const base_config_1 = require("./base-config");
exports.es2022_object = {
    ObjectConstructor: base_config_1.TYPE,
};
//# sourceMappingURL=es2022.object.js.map