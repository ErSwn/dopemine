import type { ImplicitLibVariableOptions } from '../variable';
export declare const es5: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es5.d.ts.map