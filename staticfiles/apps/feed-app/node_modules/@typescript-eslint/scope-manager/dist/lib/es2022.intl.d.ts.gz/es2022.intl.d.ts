import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2022_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2022.intl.d.ts.map