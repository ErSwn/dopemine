import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.full.d.ts.map