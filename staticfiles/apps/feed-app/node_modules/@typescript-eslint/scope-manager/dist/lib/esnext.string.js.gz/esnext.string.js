"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// RUN THE FOLLOWING COMMAND FROM THE WORKSPACE ROOT TO REGENERATE:
// npx nx generate-lib @typescript-eslint/scope-manager
Object.defineProperty(exports, "__esModule", { value: true });
exports.esnext_string = void 0;
const base_config_1 = require("./base-config");
exports.esnext_string = {
    String: base_config_1.TYPE,
};
//# sourceMappingURL=esnext.string.js.map