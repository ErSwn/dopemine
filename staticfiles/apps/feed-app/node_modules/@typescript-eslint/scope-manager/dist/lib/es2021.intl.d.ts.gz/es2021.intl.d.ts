import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2021_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2021.intl.d.ts.map