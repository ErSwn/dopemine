import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2017_object: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2017.object.d.ts.map