import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2017: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2017.d.ts.map