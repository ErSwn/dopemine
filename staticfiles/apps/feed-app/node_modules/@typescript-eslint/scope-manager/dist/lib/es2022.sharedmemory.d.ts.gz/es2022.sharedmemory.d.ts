import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2022_sharedmemory: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2022.sharedmemory.d.ts.map