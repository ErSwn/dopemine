import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2016_array_include: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2016.array.include.d.ts.map