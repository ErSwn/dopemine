import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2019_intl: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2019.intl.d.ts.map