import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2018_regexp: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.regexp.d.ts.map