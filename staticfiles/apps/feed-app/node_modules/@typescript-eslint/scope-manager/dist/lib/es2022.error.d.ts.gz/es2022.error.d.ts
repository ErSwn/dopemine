import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2022_error: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2022.error.d.ts.map