import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_date: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.date.d.ts.map