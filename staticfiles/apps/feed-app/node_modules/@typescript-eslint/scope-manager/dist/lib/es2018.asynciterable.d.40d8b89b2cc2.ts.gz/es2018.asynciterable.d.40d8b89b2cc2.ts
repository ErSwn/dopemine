import type { ImplicitLibVariableOptions } from '../variable';
export declare const es2018_asynciterable: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.asynciterable.d.ts.map