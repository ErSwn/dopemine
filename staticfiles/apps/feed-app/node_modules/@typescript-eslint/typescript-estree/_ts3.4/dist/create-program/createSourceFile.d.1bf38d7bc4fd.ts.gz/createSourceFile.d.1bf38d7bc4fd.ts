import * as ts from 'typescript';
import { ParseSettings } from '../parseSettings';
declare function createSourceFile(parseSettings: ParseSettings): ts.SourceFile;
export { createSourceFile };
//# sourceMappingURL=createSourceFile.d.ts.map
