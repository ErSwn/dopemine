"use strict";
// These types are internal to TS.
// They have been trimmed down to only include the relevant bits
// We use some special internal TS apis to help us do our parsing flexibly
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=WatchCompilerHostOfConfigFile.js.map