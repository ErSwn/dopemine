declare const typescriptVersionIsAtLeast: Record<"3.7" | "3.8" | "3.9" | "4.0" | "4.1" | "4.2" | "4.3" | "4.4" | "4.5" | "4.6" | "4.7" | "4.8", boolean>;
export { typescriptVersionIsAtLeast };
//# sourceMappingURL=version-check.d.ts.map