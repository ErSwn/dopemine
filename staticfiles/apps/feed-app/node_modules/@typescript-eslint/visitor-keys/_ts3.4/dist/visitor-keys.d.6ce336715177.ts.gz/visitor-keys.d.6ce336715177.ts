interface VisitorKeys {
    readonly [type: string]: readonly string[] | undefined;
}
declare const visitorKeys: VisitorKeys;
export { visitorKeys, VisitorKeys };
//# sourceMappingURL=visitor-keys.d.ts.map
