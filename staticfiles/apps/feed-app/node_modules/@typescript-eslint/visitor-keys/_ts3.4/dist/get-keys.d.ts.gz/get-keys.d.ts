import { TSESTree } from '@typescript-eslint/types';
declare const getKeys: (node: TSESTree.Node) => ReadonlyArray<string>;
export { getKeys };
//# sourceMappingURL=get-keys.d.ts.map
