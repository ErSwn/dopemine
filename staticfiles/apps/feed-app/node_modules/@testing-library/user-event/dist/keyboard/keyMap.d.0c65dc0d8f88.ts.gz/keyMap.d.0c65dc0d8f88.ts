import { keyboardKey } from './types';
/**
 * Mapping for a default US-104-QWERTY keyboard
 */
export declare const defaultKeyMap: keyboardKey[];
