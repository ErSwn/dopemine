import { keyboardState } from '../types';
export declare function carryValue(element: Element, state: keyboardState, newValue: string): void;
