'use strict';

module.exports = {
  action: require('./action'),
  clear: require('./clear'),
  style: require('./style'),
  strip: require('./strip'),
  figures: require('./figures'),
  lines: require('./lines'),
  wrap: require('./wrap'),
  entriesToDisplay: require('./entriesToDisplay')
};
