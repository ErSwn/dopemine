import valuesParser from 'postcss-value-parser';
export default function getCustomPropertiesFromRoot(root: any, opts: any): Map<string, valuesParser.ParsedValue>;
