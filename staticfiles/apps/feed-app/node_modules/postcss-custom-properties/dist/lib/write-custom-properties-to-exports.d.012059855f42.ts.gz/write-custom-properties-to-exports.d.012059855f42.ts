import type { ExportOptions } from './options';
export default function writeCustomPropertiesToExports(customProperties: any, destinations: Array<ExportOptions>): Promise<void[]>;
