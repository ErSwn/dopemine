"use strict";

Object.defineProperty(exports, "t", {
    value: true
});

exports.throwIteratorAccessError = throwIteratorAccessError;

function throwIteratorAccessError() {
    throw new RangeError("Iterator access denied!");
}
//# sourceMappingURL=throwError.js.map
