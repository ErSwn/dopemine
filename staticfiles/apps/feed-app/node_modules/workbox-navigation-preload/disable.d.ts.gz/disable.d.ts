import './_version.js';
/**
 * If the browser supports Navigation Preload, then this will disable it.
 *
 * @memberof workbox-navigation-preload
 */
declare function disable(): void;
export { disable };
