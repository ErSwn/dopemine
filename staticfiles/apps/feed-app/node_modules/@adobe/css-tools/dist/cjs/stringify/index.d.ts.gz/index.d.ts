import { CssStylesheetAST } from '../type';
import Compiler from './compiler';
declare const _default: (node: CssStylesheetAST, options?: ConstructorParameters<typeof Compiler>[0]) => string;
export default _default;
