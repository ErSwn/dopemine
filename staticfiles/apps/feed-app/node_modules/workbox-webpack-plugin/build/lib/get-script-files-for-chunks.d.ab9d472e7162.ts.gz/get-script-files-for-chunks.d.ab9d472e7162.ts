import { Compilation } from 'webpack';
export declare function getScriptFilesForChunks(compilation: Compilation, chunkNames: Array<string>): Array<string>;
