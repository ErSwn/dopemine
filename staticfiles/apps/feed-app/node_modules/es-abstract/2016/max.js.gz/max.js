'use strict';

var GetIntrinsic = require('get-intrinsic');

// https://262.ecma-international.org/6.0/#sec-algorithm-conventions

module.exports = GetIntrinsic('%Math.max%');
