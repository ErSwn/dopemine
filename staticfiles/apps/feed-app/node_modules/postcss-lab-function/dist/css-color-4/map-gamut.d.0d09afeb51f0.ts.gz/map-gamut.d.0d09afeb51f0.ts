declare type color = [number, number, number];
export declare function mapGamut(startOKLCH: color, toDestination: (x: color) => color, fromDestination: (x: color) => color): color;
export declare function clip(color: color): color;
export declare function inGamut(x: color): boolean;
export {};
