import async from 'resolve/async';
import sync from 'resolve/sync';

export { async, sync };
