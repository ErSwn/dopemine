declare const path: any;
declare const fs: any;
declare const isModuleResolutionError: (ex: unknown) => boolean;
declare let eslintrcBundlePath: string | undefined;
declare let configArrayFactoryPath: string | undefined;
declare let moduleResolverPath: string | undefined;
declare let eslintFolder: string | undefined;
declare const eslintPackageJson: any;
declare const eslintPackageObject: any;
declare const eslintPackageVersion: any;
declare const versionMatch: RegExpExecArray | null;
declare const eslintMajorVersion: number;
declare let ConfigArrayFactory: any;
//# sourceMappingURL=modern-module-resolution.d.ts.map